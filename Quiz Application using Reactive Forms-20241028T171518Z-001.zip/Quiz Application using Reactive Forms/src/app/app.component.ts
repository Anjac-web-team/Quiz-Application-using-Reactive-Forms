import { NgFor, NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,FormsModule,NgIf,NgFor],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  page: string = 'login';  // Current page
  user: any = {            // User information
    name: '',
    rollNo: '',
    class: '',
    subject: ''
  };
  questions: any[] = [];   // Questions for the quiz
  answers: string[] = [];  // User's answers
  score: number = 0;       // Quiz score

  // Predefined quiz questions for each subject
  quizData: any = {
    SE: [
      { text: 'What is SE?', options: ['Software Engineering', 'System Engineering', 'Social Engineering'] },
      { text: 'What does SE focus on?', options: ['Process', 'Code', 'Testing'] },
      { text: 'Which is not a part of SE?', options: ['Design', 'Documentation', 'Creativity'] },
      { text: 'What is SDLC?', options: ['Software Development Life Cycle', 'System Life Cycle', 'Software Life'] },
      { text: 'Which is a SE model?', options: ['Waterfall', 'Top-down', 'Prototype'] }
    ],
    MST: [
      { text: 'What is MST?', options: ['Management Science', 'Mathematics', 'Modern Science'] },
      { text: 'MST is used in?', options: ['Project Management', 'Software Testing', 'System Analysis'] },
      { text: 'Which is a tool used in MST?', options: ['PERT', 'JIRA', 'SPSS'] },
      { text: 'What is a critical path?', options: ['Longest Path', 'Shortest Path', 'Circular Path'] },
      { text: 'MST is related to?', options: ['Operations Research', 'Mathematical Logic', 'Physics'] }
    ],
    'AI&ML': [
      { text: 'What is AI?', options: ['Artificial Intelligence', 'Advanced Intelligence', 'Algorithmic Intelligence'] },
      { text: 'Which is a type of ML?', options: ['Supervised Learning', 'Automated Learning', 'Deep Learning'] },
      { text: 'AI is used in?', options: ['Robotics', 'Software Testing', 'Database Management'] },
      { text: 'What is Deep Learning?', options: ['Neural Networks', 'Shallow Learning', 'Machine Learning'] },
      { text: 'AI is based on?', options: ['Data', 'Code', 'Testing'] }
    ]
  };

  // Start the quiz based on selected subject
  startQuiz() {
    if (this.user.subject) {
      this.page = 'quiz';
      this.questions = this.quizData[this.user.subject];
      this.answers = new Array(this.questions.length).fill('');
    }
  }

  // Submit the quiz and calculate the score
  submitQuiz() {
    this.page = 'result';
    this.score = this.answers.filter((answer, index) => answer === this.questions[index].options[0]).length;
  }
}
